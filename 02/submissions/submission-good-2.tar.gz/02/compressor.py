class Compressor:
    def __init__(self):
        pass

    def __iter__(self):
        pass

    def append(self, x):
        pass
