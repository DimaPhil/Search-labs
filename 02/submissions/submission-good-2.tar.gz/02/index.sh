#!/bin/bash
python main.py create_index index.pkl "$@"
