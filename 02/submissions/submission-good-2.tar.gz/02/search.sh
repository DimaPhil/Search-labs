#!/bin/bash
python main.py perform_search index.pkl
